<!--script src="js/jquery.timeago.js" type="text/javascript"></script-->
<!--<script src="js/jquery.eventCalendar.min.js" type="text/javascript"></script>-->
<script src="js/moment.js" type="text/javascript"></script>
<script src="js/jquery.eventCalendar.js" type="text/javascript"></script>

</html>